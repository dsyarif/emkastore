<?php
function rupiah($duit)
{
  $hasil = "Rp." . number_format($duit, 0, ',', '.');
  return $hasil;
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= $title; ?></title>
  <link rel="shortcut icon" type="image/png" href="<?= base_url() ?>/assets/images/icon.svg">
  <style>
    body {
      font-family: "Trebuchet MS, Arial, Helvetica, sans-serif";
    }

    .card {
      font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
      font-size: 14px;
    }

    table {
      border-collapse: collapse;
      /* Removes default table spacing */
      width: 100%;
      /* Set a width for the table */
    }

    th,
    td {
      border: 1px solid black;
      padding: 8px;
    }

    table th {
      background-color: #e0e0e0;
      /* Light gray for headers */
    }
  </style>

  <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous"> -->
</head>

<body>
  <div style="text-align:center; margin-bottom: 10px;">
    <p style="font-family: Trebuchet MS, Arial, Helvetica, sans-serif; padding-left: 15px;padding-right: 15px;"><b>LAPORAN BARANG MASUK EMKA STORE</b></p>
    <p style="font-family: Trebuchet MS, Arial, Helvetica, sans-serif; padding-left: 15px;padding-right: 15px; font-size: small; margin-top: -10px;"><b>Periode</b> : <?= date('d/m/Y', strtotime($tgl_awal)) ?> - <?= date('d/m/Y', strtotime($tgl_akhir)) ?></p>
  </div>
  <br>
  <div class=" col-xl-12 col-lg-12">
    <div class="card">
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered">
            <thead>
              <tr>
                <th>No</th>
                <th>Tanggal Masuk</th>
                <th>Nama Barang</th>
                <th>Jumlah</th>
                <th>Harga Satuan</th>
                <th>Harga Total</th>
              </tr>
            </thead>
            <tbody>
              <?php
              $no = 1;
              $total = 0;
              foreach ($barang_masuk as $k) : ?>
                <tr>
                  <td style="text-align: center;"><?= $no++; ?></td>
                  <td style="text-align: center;"><?= date('d M Y', strtotime($k['tanggal_masuk'])); ?></td>
                  <td><?= $k['nm_barang']; ?></td>
                  <td style="text-align: center;"><?= $k['jumlah_masuk']; ?></td>
                  <td style="text-align: center;"><?= rupiah($k['harga_beli']); ?></td>
                  <td style="text-align: center;"><?= rupiah($k['jumlah_masuk'] * $k['harga_beli']); ?></td>
                </tr>
              <?php
                $total += $k['jumlah_masuk'] * $k['harga_beli'];
              endforeach
              ?>
              <tr style="background-color: #e0e0e0;">
                <td colspan="5" style="text-align: center;"><b>Total</b></td>
                <td style="text-align: center;"><b><?= rupiah($total); ?></b></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div>

</body>

</html>