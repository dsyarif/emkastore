<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;

class Transaksi extends BaseController
{
  //barang masuk
  public function index()
  {
    $data = array(
      'title'         => 'Barang Masuk',
      'barang'        => $this->barang->join('kategori_tb', 'barang_tb.id_kategori=kategori_tb.id_kategori', 'left')->join('sub_kategori_tb', 'barang_tb.id_sub_kategori=sub_kategori_tb.id_sub_kategori', 'left')->join('supplier_tb', 'barang_tb.id_supplier=supplier_tb.id_supplier', 'left')->orderBy('kode_barang', 'Asc')->findAll(),
      'barang_masuk' => $this->barang_masuk->join('barang_tb', 'barang_masuk_tb.kode_barang=barang_tb.kode_barang', 'left')->join('supplier_tb', 'barang_tb.id_supplier=supplier_tb.id_supplier', 'left')->orderBy('id_barang_masuk', 'desc')->findAll()
    );

    return view('barang_masuk_view', $data);
  }


  public function save_barang_masuk()
  {
    $data = [
      'kode_barang'           => $this->request->getVar('kode_barang'),
      'tanggal_masuk'         => $this->request->getVar('tanggal_masuk'),
      'jumlah_masuk'          => $this->request->getVar('jumlah_masuk'),
    ];
    $this->barang_masuk->save($data);
    session()->setFlashdata('success', 'Data Berhasil Disimpan');

    return redirect()->to('barang-masuk');
  }

  public function update_barang_masuk()
  {
    $data = [
      'id_barang_masuk'       => $this->request->getVar('id_barang_masuk'),
      'kode_barang'           => $this->request->getVar('kode_barang'),
      'tanggal_masuk'         => $this->request->getVar('tanggal_masuk'),
      'jumlah_masuk'          => $this->request->getVar('jumlah_masuk'),
    ];
    $this->barang_masuk->save($data);
    session()->setFlashdata('success', 'Data Berhasil Diubah');

    return redirect()->to('barang-masuk');
  }

  public function delete_barang_masuk($id)
  {
    $this->barang_masuk->delete($id);
    return $this->response->setJSON([
      'error' => false,
      'message' => 'Data Berhasil Dihapus!'
    ]);
  }

  public function barang_keluar()
  {
    $data = array(
      'title'         => 'Barang Keluar',
      'barang'        => $this->barang->join('kategori_tb', 'barang_tb.id_kategori=kategori_tb.id_kategori', 'left')->join('sub_kategori_tb', 'barang_tb.id_sub_kategori=sub_kategori_tb.id_sub_kategori', 'left')->join('supplier_tb', 'barang_tb.id_supplier=supplier_tb.id_supplier', 'left')->orderBy('kode_barang', 'Asc')->findAll(),
      'barang_keluar' => $this->barang_keluar->join('barang_tb', 'barang_keluar_tb.kode_barang=barang_tb.kode_barang', 'left')->orderBy('id_barang_keluar', 'desc')->findAll()
    );

    return view('barang_keluar_view', $data);
  }


  public function save_barang_keluar()
  {
    $kode_barang = $this->request->getVar('kode_barang');
    $stok =  $this->barang->selectSum('stok')->where('kode_barang', $kode_barang)->first();
    $barang_masuk = $this->barang_masuk->selectSum('jumlah_masuk')->where('kode_barang', $kode_barang)->first();
    $total_stok = ($barang_masuk['jumlah_masuk'] + $stok['stok']);
    $jml_keluar = $this->request->getVar('jumlah_keluar');
    $data = [
      'kode_barang'     => $kode_barang,
      'tanggal_keluar'  => $this->request->getVar('tanggal_keluar'),
      'jumlah_keluar'   => $jml_keluar,
      'keterangan'      => $this->request->getVar('keterangan'),
      'alasan'          => $this->request->getVar('alasan'),
    ];
    if ($total_stok < $jml_keluar) {
      session()->setFlashdata('danger', 'Data Gagal Disimpan, karena melebih stok yang ada');
    } else {
      $this->barang_keluar->save($data);
      session()->setFlashdata('success', 'Data Berhasil Disimpan');
    }


    return redirect()->to('barang-keluar');
  }

  public function update_barang_keluar()
  {
    $data = [
      'id_barang_keluar' => $this->request->getVar('id_barang_keluar'),
      'kode_barang'     => $this->request->getVar('kode_barang'),
      'tanggal_keluar'  => $this->request->getVar('tanggal_keluar'),
      'jumlah_keluar'   => $this->request->getVar('jumlah_keluar'),
      'keterangan'      => $this->request->getVar('keterangan'),
      'alasan'          => $this->request->getVar('alasan'),
    ];
    $this->barang_keluar->save($data);
    session()->setFlashdata('success', 'Data Berhasil Diubah');

    return redirect()->to('barang-keluar');
  }

  public function delete_barang_keluar($id)
  {
    $this->barang_keluar->delete($id);
    return $this->response->setJSON([
      'error' => false,
      'message' => 'Data Berhasil Dihapus!'
    ]);
  }
}
